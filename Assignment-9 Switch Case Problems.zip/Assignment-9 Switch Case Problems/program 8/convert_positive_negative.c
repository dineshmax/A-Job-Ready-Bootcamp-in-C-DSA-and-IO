#include<stdio.h>
#include<conio.h>
int main()
{
    int x;
    printf("Enter a number ");
    scanf("%d",&x);
    switch(x>0)
    {
        case 1:
            x=-x;
            printf("%d",x);
            break;
        case 0:
            x=-x;
            printf("%d",x);
            break;
    }

    getch();
    return 0;
}
