#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
int main()
{
    while(1)
    {
        int a,b,c,option;
        system("cls");
        printf("\n1.Check Isosceles Triangle ");
        printf("\n2.Check Right Angled Triangle ");
        printf("\n3.Check Equilateral Triangle ");
        printf("\n4.Exit ");

        printf("\n\nEnter any option ");
        scanf("%d",&option);
        switch(option)
        {
            case 1:
                printf("Enter three numbers ");
                scanf("%d%d%d",&a,&b,&c);
                    if(a==b || b==c || c==a)
                        printf("Yes, It's Isosceles Triangle");
                    else
                        printf("No, It's not a Isosceles Triangle");
                break;
            case 2:
                printf("Enter three numbers ");
                scanf("%d%d%d",&a,&b,&c);
                    if(a*a+b*b==c*c || b*b+c*c==a*a ||c*c+a*a==b*b)
                        printf("Yes, It's right angled Triangle");
                    else
                        printf("No, It's not a right angled Triangle");
                break;
            case 3:
                printf("Enter three numbers ");
                scanf("%d%d%d",&a,&b,&c);
                    if(a==b && b==c && c==a)
                        printf("Yes, It's Equilateral Triangle");
                    else
                        printf("No, It's not a Equilateral Triangle");
                break;
            case 4:
                exit(0);
            default:
                printf("Invalid entry");
        }

    getch();
    }
    return 0;
}

