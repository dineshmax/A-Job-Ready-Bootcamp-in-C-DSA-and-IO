#include<stdio.h>
#include<conio.h>
int main()
{
    float x;
    printf("Enter a unit ");
    scanf("%f",&x);
    switch(x<=50)
    {
        case 1:
            x=x*0.50;
            break;
        case 0:
            switch(x<=150)
            {
                case 1:
                    x=((50*0.50)+(x-50)*0.75);
                    break;
                case 0:
                    switch(x<=250)
                    {
                        case 1:
                            x=((50*0.50)+(100*0.75)+(x-150)*1.20);
                            break;
                        case 0:
                            x=((50*0.50)+(100*0.75)+(100*1.20)+(x-250)*1.50);
                            break;
                    }
                    break;
            }
        break;
    }
    x=(x+(x*20/100));
    printf("Electricity bill is %.2f",x);

    getch();
    return 0;
}
