#include<stdio.h>
#include<conio.h>
int main()
{
    int day;
    printf("Enter a day of week ");
    scanf("%d",&day);
    switch(day)
    {
        case 1:
            printf("Hello, It's Sunday");
            break;
        case 2:
            printf("Hello, It's Monday");
            break;
        case 3:
            printf("Hello, It's Tuesday");
            break;
        case 4:
            printf("Hello, It's Wednesday");
            break;
        case 5:
            printf("Hello, It's Thursday");
            break;
        case 6:
            printf("Hello, It's Friday");
            break;
        case 7:
            printf("Hello, It's Saturday");
            break;
        default:
            printf("Invalid day entry");
    }

    getch();
    return 0;
}
