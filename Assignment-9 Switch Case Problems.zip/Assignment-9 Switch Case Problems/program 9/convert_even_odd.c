#include<stdio.h>
#include<conio.h>
int main()
{
    int x;
    printf("Enter an even number ");
    scanf("%d",&x);
    switch(x%2==0)
    {
    case 1:
        printf("Upper nearest odd number is %d",x+1);
        break;
    case 0:
        printf("Invalid number");
        break;
    }

    getch();
    return 0;
}
