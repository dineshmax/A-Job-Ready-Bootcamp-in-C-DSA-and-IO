#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
int main()
{
    while(1)
    {
        int a,b,option;
        system("cls");
        printf("\n1.Addition ");
        printf("\n2.Subtraction ");
        printf("\n3.Multiplication ");
        printf("\n4.Division ");
        printf("\n5.Exit ");

        printf("\n\nEnter any option ");
        scanf("%d",&option);
        switch(option)
        {
            case 1:
                printf("Enter two numbers ");
                scanf("%d%d",&a,&b);
                printf("Sum is %d",a+b);
                break;
            case 2:
                printf("Enter two numbers ");
                scanf("%d%d",&a,&b);
                printf("Subtraction is %d",a-b);
                break;
            case 3:
                printf("Enter two numbers ");
                scanf("%d%d",&a,&b);
                printf("Multiplication is %d",a*b);
                break;
            case 4:
                printf("Enter two numbers ");
                scanf("%d%d",&a,&b);
                printf("Division is %d",a/b);
                break;
            case 5:
                exit(0);
            default:
                printf("Invalid entry");
        }

    getch();
    }
    return 0;
}
