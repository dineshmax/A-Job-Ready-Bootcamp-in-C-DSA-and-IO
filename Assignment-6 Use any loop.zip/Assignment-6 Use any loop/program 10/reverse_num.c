#include<stdio.h>
#include<conio.h>
int main()
{
    int n,x,num=0;
    printf("Enter a number ");
    scanf("%d",&n);
    while(n)
    {
        x=n%10;
        num=num*10+x;
        n=n/10;
    }
    printf("Reverse number is %d",num);

    getch();
    return 0;
}
