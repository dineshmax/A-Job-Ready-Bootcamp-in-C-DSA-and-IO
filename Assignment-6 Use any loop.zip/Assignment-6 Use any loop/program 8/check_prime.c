#include<stdio.h>
#include<conio.h>
int main()
{
    int x,i;
    printf("Enter N number ");
    scanf("%d",&x);
    for(i=2;i<x;i++)
        if(x%i==0)
        break;
    if(i==x)
        printf("Prime number");
    else
        printf("Not Prime");

    getch();
    return 0;
}
