#include<stdio.h>
#include<conio.h>
int main()
{
    int n,i,sum=0;
    printf("Enter N number ");
    scanf("%d",&n);
    for(i=1;i<=n;i++)
        sum=sum+i*i;
    printf("Sum of squares of first %d natural number is %d",n,sum);


    getch();
    return 0;
}
