#include<stdio.h>
#include<conio.h>
int main()
{
    int n,i,count=0;
    printf("Enter N number ");
    scanf("%d",&n);
    while(n)
    {
        n=n/10;
        count++;
    }
    printf("Count digits of entered number is %d",count);

    getch();
    return 0;
}
