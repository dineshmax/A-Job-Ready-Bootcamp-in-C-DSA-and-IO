#include<stdio.h>
#include<conio.h>
int main()
{
    int n,i,p=1;
    printf("Enter N number ");
    scanf("%d",&n);
    for(i=0;i<n-1;i++)
        p=p*(n-i);
    printf("Factorial of %d is %d",n,p);

    getch();
    return 0;
}
