#include<stdio.h>
#include<conio.h>
int comb(int,int);
int fact(int);
int main()
{
    int n,r,nCr;
    printf("Enter items and selection ");
    scanf("%d%d",&n,&r);
    nCr=comb(n,r);
    printf("Number of combination is %d",nCr);

    getch();
    return 0;
}
//Define functions
int comb(int N,int R)
{
    int c;
    c=fact(N)/(fact(N-R)*fact(R));
    return c;
}
int fact(int n)
{
    int i,p=1;
    for(i=0;i<n;i++)
        p=p*(n-i);
    return p;
}

