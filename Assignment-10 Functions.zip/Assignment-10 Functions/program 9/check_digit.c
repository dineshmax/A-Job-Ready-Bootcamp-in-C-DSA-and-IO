#include<stdio.h>
#include<conio.h>
int check_digit(int,int);
int main()
{
    int n,x,s;
    printf("Enter a number and a digit ");
    scanf("%d%d",&n,&x);
    s=check_digit(n,x);
    if(s==1)
        printf("Yes, given number contains a given digit");
    else
        printf("No, given number contains not a given digit");

    getch();
    return 0;
}
//Define functions
int check_digit(int num,int digit)
{
    int y;
    while(num)
    {
        y=num%10;
        if(digit==y)
            return 1;
        num=num/10;
    }
    return 0;
}

