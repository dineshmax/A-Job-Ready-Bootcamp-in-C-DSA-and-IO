#include<stdio.h>
#include<conio.h>
void print_N(int);
int main()
{
    int n;
    printf("Enter N number ");
    scanf("%d",&n);
    print_N(n);

    getch();
    return 0;
}
void print_N(int x)
{
    int i;
    for(i=1;i<=x;i++)
    printf("%d ",i);
}
