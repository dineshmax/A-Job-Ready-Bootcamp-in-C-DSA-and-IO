#include<stdio.h>
#include<conio.h>
int even_odd(int);
int main()
{
    int x,s;
    printf("Enter a number ");
    scanf("%d",&x);
    s=even_odd(x);
    if(s==1)
        printf("Even");
    else
        printf("Odd");

    getch();
    return 0;
}
int even_odd(int n)
{
    if(n%2)
        return 0;
    else
        return 1;
}

