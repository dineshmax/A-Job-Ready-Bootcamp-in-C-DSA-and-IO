#include<stdio.h>
#include<conio.h>
float area_circle(int);
int main()
{
    int r;
    float a;
    printf("Enter a radius ");
    scanf("%d",&r);
    a=area_circle(r);
    printf("Area of circle is %.2f",a);

    getch();
    return 0;
}
float area_circle(int x)
{
    return 3.14*x*x;
}
