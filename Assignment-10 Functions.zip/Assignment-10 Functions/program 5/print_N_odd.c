#include<stdio.h>
#include<conio.h>
void print_N_odd(int);
int main()
{
    int n;
    printf("Enter N number ");
    scanf("%d",&n);
    print_N_odd(n);

    getch();
    return 0;
}
void print_N_odd(int x)
{
    int i;
    for(i=1;i<=x;i++)
        printf("%d ",2*i-1);
}
