#include<stdio.h>
#include<conio.h>
int perm(int,int);
int fact(int);
int main()
{
    int n,r,nPr;
    printf("Enter items and selection ");
    scanf("%d%d",&n,&r);
    nPr=perm(n,r);
    printf("Number of arrangements is %d",nPr);

    getch();
    return 0;
}
//Define functions
int perm(int N,int R)
{
    int c;
    c=fact(N)/fact(N-R);
    return c;
}
int fact(int n)
{
    int i,p=1;
    for(i=0;i<n;i++)
        p=p*(n-i);
    return p;
}
