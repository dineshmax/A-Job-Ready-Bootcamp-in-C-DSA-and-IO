#include<stdio.h>
#include<conio.h>
void prime_fact(int);
int main()
{
    int num;
    printf("Enter a number ");
    scanf("%d",&num);
    prime_fact(num);

    getch();
    return 0;
}
//Define functions
void prime_fact(int n)
{
    int i;
    while(n!=1)
    {
        for(i=2;i<=n;i++)
        {
            if(n%i==0)
            {
                printf("%d ",i);
                break;
            }
        }
        n=n/i;
    }
}

