#include<stdio.h>
#include<conio.h>
int fact(int);
int main()
{
    int x,F;
    printf("Enter a number ");
    scanf("%d",&x);
    F=fact(x);
    printf("Factorial of %d is %d",x,F);

    getch();
    return 0;
}
int fact(int n)
{
    int i,p=1;
    for(i=0;i<n;i++)
        p=p*(n-i);
    return p;
}
