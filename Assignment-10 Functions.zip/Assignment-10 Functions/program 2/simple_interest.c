#include<stdio.h>
#include<conio.h>
float simple_intrst(int,float,int);
int main()
{
    int p,t;
    float r,SI;
    printf("Enter principal, rate and time ");
    scanf("%d%f%d",&p,&r,&t);
    SI=simple_intrst(p,r,t);
    printf("Simple interest is %.2f",SI);

    getch();
    return 0;
}
float simple_intrst(int P,float R,int T)
{
    return (P*R*T)/100;
}
