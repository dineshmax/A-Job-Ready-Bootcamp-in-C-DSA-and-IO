#include<stdio.h>
#include<conio.h>
int main()
{
    int n,x;
    printf("Enter a number ");
    scanf("%d",&n);
    x=n/10;
    printf("Number without last digit is %d",x);

    getch();
    return 0;
}
