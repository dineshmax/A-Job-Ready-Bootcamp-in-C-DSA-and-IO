#include<stdio.h>
#include<conio.h>
int main()
{
    int n,x;
    printf("Enter a number ");
    scanf("%d",&n);
    x=n&1;
    if(x==1)
        printf("Odd");
    else
        printf("Even");

    getch();
    return 0;
}
