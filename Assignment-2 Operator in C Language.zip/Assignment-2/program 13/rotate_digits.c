#include<stdio.h>
#include<conio.h>
int main()
{
    int n,x;
    printf("Enter any 3 digits number ");
    scanf("%d",&n);
    x=n%10;
    n=n/10;
    x=x*100+n;
    printf("%d",x);

    getch();
    return 0;
}
