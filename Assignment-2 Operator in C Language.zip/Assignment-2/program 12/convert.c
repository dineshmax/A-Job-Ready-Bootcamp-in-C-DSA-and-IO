#include<stdio.h>
#include<conio.h>
int main()
{
    int INR;
    float USD;
    printf("Enter any amount ");
    scanf("%d",&INR);
    USD=INR*1/76.23;
    printf("%f USD",USD);

    getch();
    return 0;
}
