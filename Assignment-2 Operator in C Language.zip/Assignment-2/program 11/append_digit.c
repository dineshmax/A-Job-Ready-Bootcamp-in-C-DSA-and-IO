#include<stdio.h>
#include<conio.h>
int main()
{
    int x,n;
    printf("Enter a number ");
    scanf("%d",&x);
    printf("Enter a digit ");
    scanf("%d",&n);
    x=x*10+n;
    printf("%d",x);

    getch();
    return 0;
}
