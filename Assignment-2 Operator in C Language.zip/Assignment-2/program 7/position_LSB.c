#include<stdio.h>
#include<conio.h>
int main()
{
    int x,n,count=0;
    printf("Enter a number ");
    scanf("%d",&n);
    while(n!=0)
    {
        x=n&1;
        count++;
        if(x==1)
        {
            printf("Position of first 1 in LSB is %d",count);
            break;
        }
        n=n>>1;
    }

    getch();
    return 0;
}
