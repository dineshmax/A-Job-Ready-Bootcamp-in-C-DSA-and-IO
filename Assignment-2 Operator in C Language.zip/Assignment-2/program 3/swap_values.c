#include<stdio.h>
#include<conio.h>
int main()
{
    int a,b,t;
    printf("Enter two numbers ");
    scanf("%d%d",&a,&b);
    t=a;
    a=b;
    b=t;
    printf("a=%d b=%d",a,b);

    getch();
    return 0;
}
