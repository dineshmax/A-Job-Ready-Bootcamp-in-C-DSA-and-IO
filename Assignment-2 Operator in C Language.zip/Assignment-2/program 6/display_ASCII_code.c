#include<stdio.h>
#include<conio.h>
int main()
{
    char x;
    printf("Enter a character ");
    scanf("%c",&x);
    printf("%d",x);

    getch();
    return 0;
}
