#include<stdio.h>
#include<conio.h>
int main()
{
    int a,x;
    float b;
    char c;
    double d;
    x=sizeof(a);
    printf("size of an int type variable is %d\n",x);

    x=sizeof(b);
    printf("size of a float type variable is %d\n",x);

    x=sizeof(c);
    printf("size of a char type variable is %d\n",x);

    x=sizeof(d);
    printf("size of a double type variable is %d\n",x);


    getch();
    return 0;
}
