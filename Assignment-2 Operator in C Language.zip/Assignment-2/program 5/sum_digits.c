#include<stdio.h>
#include<conio.h>
int main()
{
    int n,x,s=0;
    printf("Enter a 3 digit number ");
    scanf("%d",&n);

    x=n%10;
    n=n/10;
    s=s+x;

    x=n%10;
    n=n/10;
    s=s+x;

    x=n%10;
    n=n/10;
    s=s+x;

    printf("Sum of 3 digits number is %d",s);

    getch();
    return 0;
}
