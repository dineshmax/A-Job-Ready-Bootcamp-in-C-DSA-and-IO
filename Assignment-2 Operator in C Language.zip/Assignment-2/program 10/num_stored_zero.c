#include<stdio.h>
#include<conio.h>
int main()
{
    int x;
    printf("Enter a number ");
    scanf("%d",&x);
    x=x/10;
    x=x*10;
    printf("%d",x);

    getch();
    return 0;
}
