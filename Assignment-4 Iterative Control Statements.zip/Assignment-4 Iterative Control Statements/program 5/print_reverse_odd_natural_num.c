#include<stdio.h>
#include<conio.h>
int main()
{
    int i;
    for(i=10;i>=1;i--)
        printf("%d ",2*i-1);

    getch();
    return 0;
}
