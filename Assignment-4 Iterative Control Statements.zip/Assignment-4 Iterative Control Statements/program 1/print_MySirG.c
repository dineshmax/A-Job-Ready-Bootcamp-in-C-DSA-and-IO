#include<stdio.h>
#include<conio.h>
int main()
{
    int i;
    for(i=0;i<5;i++)
    printf("MySirG\n");

    getch();
    return 0;
}
