#include<stdio.h>
#include<conio.h>
int main()
{
    int i;
    for(i=1;i<=10;i++)
        printf("%d ",11-i);

    getch();
    return 0;
}
