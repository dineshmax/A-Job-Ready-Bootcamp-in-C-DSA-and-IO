#include<stdio.h>
#include<conio.h>
int main()
{
    int n,i;
    for(i=1,n=5;i<=10;i++)
        printf("%d x %d = %d\n",n,i,n*i);

    getch();
    return 0;
}
