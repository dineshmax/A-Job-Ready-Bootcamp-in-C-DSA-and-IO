#include<stdio.h>
#include<conio.h>
int main()
{
    float cp,sp,pop,lop;
    printf("Enter cost price of a product ");
    scanf("%f",&cp);
    printf("\nEnter selling price of a product ");
    scanf("%f",&sp);
    pop=(sp-cp)/cp*100;
    lop=(cp-sp)/cp*100;

    if(cp<sp)
        printf("%.2f%% profit",pop);
    else
        printf("%.2f%% loss",lop);

    getch();
    return 0;
}
