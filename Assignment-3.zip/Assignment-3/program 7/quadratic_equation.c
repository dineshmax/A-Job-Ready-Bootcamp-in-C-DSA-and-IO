#include<stdio.h>
#include<conio.h>
#include<math.h>
int main()
{
    int a,b,c,D;
    float x,y;
    printf("Enter coefficient of a quadratic equation ");
    scanf("%d%d%d",&a,&b,&c);
    D=b*b-4*a*c;
    if(D<0)
        printf("Roots are imaginary");
    if(D>0){
        printf("Roots are real and distinct");
        x=(-b+sqrt(D))/(2*a);
        y=(-b-sqrt(D))/(2*a);
        printf("\nRoots are %f and %f",x,y);
    }
    if(D==0){
        printf("Both roots are equal");
        x=-b/(2.0*a);
        printf("\nRoot is %f",x);
    }

    getch();
    return 0;
}
