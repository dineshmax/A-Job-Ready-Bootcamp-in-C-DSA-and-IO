#include<stdio.h>
#include<conio.h>
int main()
{
    int year;
    printf("Enter any year ");
    scanf("%d",&year);
    if(year%100==0)
    {
        if(year%400==0)
            printf("Leap Year");
        else
            printf("Non Leap Year");
    }
    else
    {
         if(year%4==0)
            printf("Leap Year");
         else
            printf("Non Leap Year");
    }

    getch();
    return 0;
}
