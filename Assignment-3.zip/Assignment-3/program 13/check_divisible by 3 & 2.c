#include<stdio.h>
#include<conio.h>
int main()
{
    int x;
    printf("Enter a number ");
    scanf("%d",&x);
    if(x%3==0 && x%2==0)
        printf("Divisible by 3 and 2");
    else
        printf("Not divisible by 3 and 2");

    getch();
    return 0;
}
