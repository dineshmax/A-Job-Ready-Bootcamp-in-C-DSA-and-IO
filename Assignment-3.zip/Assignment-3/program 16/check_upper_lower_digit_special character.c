#include<stdio.h>
#include<conio.h>
int main()
{
    char x;
    printf("Enter any character ");
    scanf("%c",&x);
    if(x>='A' && x<='Z')
        printf("A uppercase alphabet");
    else if(x>='a' && x<='z')
        printf("A lowercase alphabet");
    else if(x>='0' && x<='9')
        printf("A digit");
    else
        printf("A special character");

    getch();
    return 0;
}
