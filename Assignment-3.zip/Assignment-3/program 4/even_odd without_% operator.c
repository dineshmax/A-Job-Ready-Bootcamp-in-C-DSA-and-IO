#include<stdio.h>
#include<conio.h>
int main()
{
    int x,n;
    printf("Enter a number ");
    scanf("%d",&n);
    x=n&1;
    if(x==1)
        printf("odd number");
    else
        printf("even number");

    getch();
    return 0;
}
