#include<stdio.h>
#include<conio.h>
int main()
{
    int a,b,c;
    printf("Enter three numbers ");
    scanf("%d%d%d",&a,&b,&c);
    if(a>b)
        if(a>c)
            printf("greatest number is %d",a);
        else
            printf("greatest number is %d",c);
    else
        if(b>c)
            printf("greatest number is %d",b);
        else
            printf("greatest number is %d",c);

    getch();
    return 0;
}
