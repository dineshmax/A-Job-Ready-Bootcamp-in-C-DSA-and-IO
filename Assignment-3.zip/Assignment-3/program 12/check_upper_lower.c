#include<stdio.h>
#include<conio.h>
int main()
{
    char x;
    printf("Enter an alphabet ");
    scanf("%c",&x);
    if(x>='A' && x<='Z')
        printf("Uppercase");
    else
        printf("Lowercase");

    getch();
    return 0;
}
