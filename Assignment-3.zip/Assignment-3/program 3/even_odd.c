#include<stdio.h>
#include<conio.h>
int main()
{
    int x;
    printf("Enter a number ");
    scanf("%d",&x);
    if(x%2==0)
        printf("even number");
    else
        printf("odd number");

    getch();
    return 0;
}
