#include<stdio.h>
#include<conio.h>
int main()
{
    printf("Hello\nStudents");

    getch();
    return 0;
}
