#include<stdio.h>
#include<conio.h>
int main()
{
    int x=printf("ineuron");
    printf("%d",x);

    getch();
    return 0;
}
