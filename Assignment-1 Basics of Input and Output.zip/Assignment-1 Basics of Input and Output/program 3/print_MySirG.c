#include<stdio.h>
#include<conio.h>
int main()
{
    printf("\"MySirG\"");

    getch();
    return 0;
}
