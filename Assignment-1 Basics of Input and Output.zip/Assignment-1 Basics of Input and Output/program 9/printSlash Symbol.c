#include<stdio.h>
#include<conio.h>
int main()
{
    printf("\\\\");

    getch();
    return 0;
}
