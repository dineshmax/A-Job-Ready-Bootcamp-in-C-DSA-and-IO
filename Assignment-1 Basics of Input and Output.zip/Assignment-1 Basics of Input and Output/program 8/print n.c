#include<stdio.h>
#include<conio.h>
int main()
{
    printf("\\n");

    getch();
    return 0;
}
