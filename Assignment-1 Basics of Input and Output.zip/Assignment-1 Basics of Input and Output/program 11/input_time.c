#include<stdio.h>
#include<conio.h>
int main()
{
    int HH,MM;
    printf("Enter any time as HH:MM format ");
    scanf("%d:%d",&HH,&MM);
    printf("%d hours and %d Minutes",HH,MM);

    getch();
    return 0;
}
