#include<stdio.h>
#include<conio.h>
int main()
{
    int i;
    char s[20];
    printf("Enter any name ");;
    gets(s);
    printf("\"Hello, %s\"",s);

    getch();
    return 0;
}
