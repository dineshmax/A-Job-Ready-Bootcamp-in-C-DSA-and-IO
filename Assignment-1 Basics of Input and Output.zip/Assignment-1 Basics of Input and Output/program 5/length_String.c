#include<stdio.h>
#include<conio.h>
int main()
{
    int i;
    char s[20]="Ahmedabad";
    printf("Enter any string ");;
    gets(s);
    for(i=0;s[i]!='\0';i++);
    printf("%d",i);

    getch();
    return 0;
}
