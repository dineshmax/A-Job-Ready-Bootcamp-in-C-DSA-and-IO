#include<stdio.h>
#include<conio.h>
int main()
{
    int DD,MM,YYYY;
    printf("Enter any date as DD/MM/YYYY format ");
    scanf("%d/%d/%d",&DD,&MM,&YYYY);
    printf("Day-%d, Month-%d, Year-%d",DD,MM,YYYY);

    getch();
    return 0;
}
