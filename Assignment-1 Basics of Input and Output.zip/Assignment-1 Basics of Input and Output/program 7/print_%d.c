#include<stdio.h>
#include<conio.h>
int main()
{
    printf("\%%d");

    getch();
    return 0;
}
