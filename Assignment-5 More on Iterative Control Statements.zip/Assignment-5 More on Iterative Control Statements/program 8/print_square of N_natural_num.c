#include<stdio.h>
#include<conio.h>
int main()
{
    int n,i;
    printf("Enter N numbers ");
    scanf("%d",&n);
    for(i=1;i<=n;i++)
        printf("%d ",i*i);

    getch();
    return 0;
}
