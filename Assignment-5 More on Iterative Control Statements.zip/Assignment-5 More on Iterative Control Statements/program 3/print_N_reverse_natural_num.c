#include<stdio.h>
#include<conio.h>
int main()
{
    int n,i;
    printf("Enter N numbers ");
    scanf("%d",&n);
    for(i=0;i<n;i++)
        printf("%d ",n-i);

    getch();
    return 0;
}
